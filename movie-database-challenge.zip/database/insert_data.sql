-- Insert Actors
INSERT INTO Actors (name, age) VALUES
('Tom Cruise', 61),
('Emma Stone', 34),
('Denzel Washington', 68),
('Zendaya', 27);

-- Insert Movies
INSERT INTO Movies (title, year) VALUES
('Top Gun: Maverick', 2022),
('La La Land', 2016),
('Equalizer 3', 2023),
('Spider-Man: No Way Home', 2021);

-- Connect Movies & Actors
INSERT INTO MovieActors (movie_id, actor_id, role) VALUES
(1, 1, 'Captain Pete Mitchell'),
(2, 2, 'Mia Dolan'),
(3, 3, 'Robert McCall'),
(4, 4, 'MJ Watson'),
(4, 1, 'Guest Pilot');
