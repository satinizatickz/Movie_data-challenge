-- All actors
SELECT * FROM Actors;

-- All movies
SELECT * FROM Movies;

-- Actors in Spider-Man
SELECT a.name, ma.role
FROM Actors a
JOIN MovieActors ma ON a.id = ma.actor_id
JOIN Movies m ON ma.movie_id = m.id
WHERE m.title = 'Spider-Man: No Way Home';

-- Movies for Tom Cruise
SELECT m.title, m.year, ma.role
FROM Movies m
JOIN MovieActors ma ON m.id = ma.movie_id
JOIN Actors a ON ma.actor_id = a.id
WHERE a.name = 'Tom Cruise';
