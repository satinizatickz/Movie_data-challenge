# 🎬 Movie Database Challenge

A simple SQL-based database for managing movies and actors, demonstrating table creation, relationships, and querying.

---

## 🧩 Database Structure
- **Actors**: Stores actor details
- **Movies**: Stores movie info
- **MovieActors**: Connects actors to movies (many-to-many relationship)

---

## 🏗️ Setup
1. Open your SQL client (MySQL, SQLite, or PostgreSQL).
2. Run `create_tables.sql` to create tables.
3. Run `insert_data.sql` to add sample data.
4. Use `sample_queries.sql` to explore relationships.

---

## 💡 Example Queries
- Find all actors in a specific movie  
- Find all movies by a specific actor  
- List all movies released after 2020 with their cast

---

## 📜 License
This project is open-source and free to use.
